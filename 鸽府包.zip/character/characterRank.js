import {lib,game,ui,get,ai,_status} from '../../../noname.js'
let block={//武将评级
    A:[
    ],
    S:[
	"gf_gx",
	"gf_ks",
	"gf_gb",
    ],
    SS:[
        "gf_zj",
        "gf_sb",
        "gf_s",
        "gf_gp",
        "gf_sg",
	],
    SSS:[
 	"gf_bs",
	"gf_ts",
	"gf_yf",
	"gf_gh",
    ]
};
export const characterRank=block;